<!DOCTYPE HTML>
<html lang="en-US" dir="ltr"  data-config='{"twitter":0,"plusone":0,"facebook":0,"style":"dark-red"}'>




<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>GlewNet | Internet Banda Ancha</title>

 <link rel="apple-touch-icon-precomposed" href="./apple_touch_icon.png">
		
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<!-- <link rel='stylesheet' id='woocommerce-layout-css'  href='plugins/woocommerce/assets/css/woocommerce-layout16b9.css?ver=2.5.2' type='text/css' media='all' /> -->
<!-- <link rel='stylesheet' id='woocommerce-smallscreen-css'  href='plugins/woocommerce/assets/css/woocommerce-smallscreen16b9.css?ver=2.5.2' type='text/css' media='only screen and (max-width: 768px)' /> -->
<script type='text/javascript' src='js/jquery/jqueryc1d8.js?ver=1.11.3'></script>
<script type='text/javascript' src='js/jquery/jquery-migrate.min1576.js?ver=1.2.1'></script>
<meta name="generator" content="Mi Internet" />
<link rel="canonical" href="index.php" />
<link rel='shortlink' href='index.php' />
<!-- <link rel="stylesheet" href="plugins/widgetkit/cache/widgetkit-4e034456.css" /> -->
<!-- <script src="plugins/widgetkit/cache/widgetkit-10149592.js"></script> -->
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<link rel="stylesheet" href="./styles/dark-red/css/woocommerce.css">
<link rel="stylesheet" href="./styles/dark-red/css/theme.css">
<link rel="stylesheet" href="./css/custom.css">
<script src="./warp/vendor/uikit/js/uikit.js"></script>
<script src="./warp/vendor/uikit/js/components/autocomplete.js"></script>
<script src="./warp/vendor/uikit/js/components/search.js"></script>
<script src="./warp/vendor/uikit/js/components/tooltip.js"></script>
<script src="./warp/js/social.js"></script>
<script src="./js/theme.js"></script>
<script src="./js/circlechart.js"></script>
</head>

<body class="home page page-id-30 page-template-default tm-isblog wp-front_page wp-page wp-page-30 tm-navbar-fixed">


	
	
		<div class="tm-headerbar uk-clearfix">

			<div class="uk-container uk-container-center">

				
				
				
								
								
								
<div class="uk-navbar-nav uk-navbar-flip uk-hidden-small">
					<ul class="uk-navbar-nav uk-hidden-small">
					<li><a href="#" class="">Internet Banda Ancha&nbsp;&nbsp;&nbsp;&nbsp;| </a></li>
					<li><a href="/" class="">Inicio</a></li>
					<li><a href="contacto.php" class="">Contactanos</a></li>
					</ul>				</div>
								
								
								
				
				
				<span class="uk-navbar-brand uk-hidden-small">
        02224-432514 / 02224-431054          

           </span>
        
				

				
			</div>

		</div>

	
		<div class="tm-teaser">
			 <img  src="./images/int.png" height="100%" width="100%" class="uk-visible-large" style="position: absolute; bottom: 0; right:0;"> 

		<div class="uk-container uk-container-center uk-height-1-1">
			<div class="uk-height-1-1 uk-vertical-align uk-text-center-small uk-text-center-medium">

  <div class="uk-width-1-1 uk-width-medium-1-2 uk-vertical-align-middle">

         

	 <img data-uk-scrollspy="{cls:'uk-animation-slide-left', repeat: true}" src="./images/fle2.png" height="300" width="250"  class="uk-visible-large" style="position: absolute; bottom: 280px; right:150px;"> 
     <img data-uk-scrollspy="{cls:'uk-animation-slide-right', repeat: true}" src="./images/logo2.png" height="700" width="650"  class="uk-visible-large" style="position: absolute; bottom: 0; left:150px;"> 
    </div>

</div>		</div>
	</div>
	
	<div class="tm-wrapper">

		<div class="tm-block tm-position-divider tm-block-padding-bottom">
		<div class=" uk-container uk-container-center">
			<section class="tm-top-a uk-grid" data-uk-grid-match="{target:'> div > .uk-panel'}" data-uk-grid-margin>
<div class="uk-width-1-1 uk-width-medium-1-3"><div class="uk-panel uk-text-center widget_text"><div>

  <img class="tm-negativ-margin-top" src="./images/1.png" height="130" width="130" >

</div>

<h2 class="uk-margin-top-remove">

  Servicio inalambrico

</h2>

<div class="tm-mini-divider"></div>



<br>

    



 </div></div>

<div class="uk-width-1-1 uk-width-medium-1-3"><div class="uk-panel uk-text-center widget_text">  <img class="tm-negativ-margin-top" src="./images/2.png" height="130" width="130" >

  <h2 class="uk-margin-top-remove">

    Sin necesidad de telefono

  </h2>

  <div class="tm-mini-divider"></div>

 

</div></div>

<div class="uk-width-1-1 uk-width-medium-1-3"><div class="uk-panel uk-text-center widget_text"><img class="tm-negativ-margin-top" src="./images/3.png" height="130" width="130" >

<h2 class="uk-margin-top-remove">

  Sin necesidad de TV por cable

</h2>

<div class="tm-mini-divider"></div>



    

  </div></div>
</section>
		</div>
	</div>
	
		<div class="tm-block tm-block-padding-bottom ">
		<div class=" uk-container uk-container-center">
			<section class="tm-top-b uk-grid" data-uk-grid-match="{target:'> div > .uk-panel'}" data-uk-grid-margin>
<div class="uk-width-1-1">
<div class="uk-panel widget_text">
<br><br><br><br><h1 class="tm-negativ-margin-top uk-text-center">
  Cobertura de la red
</h1>
<p class="uk-width-medium-2-3 uk-align-center uk-text-center">
  <mark class="tm-mark-scribble">Prestamos servicios en la zona de:</mark>
  <h2 class="tm-negativ-margin-top uk-text-center">
<br><br>Glew - Guernica - Longchamps - Burzaco - Alejandro Korn</h2>
</p>
<img class="uk-align-center" src="./images/maps.png" height="390" width="980" >





<hr class="uk-grid-divider">



</div></div>
</section>
		</div>
	</div>
	
		<div class="tm-block tm-block-padding-top-bottom tm-block-secondary ">
		<div class=" uk-container uk-container-center">

			
			<div class="tm-middle uk-grid" data-uk-grid-match data-uk-grid-margin>

								<div class="tm-main uk-width-medium-1-1">

										<section class="tm-main-top uk-grid" data-uk-grid-match="{target:'> div > .uk-panel'}" data-uk-grid-margin>


<div class="uk-width-1-1 uk-width-medium-1-2"><div class="uk-panel widget_text"><div class="uk-grid">

<div class="uk-width-large-1-6 uk-width-2-6">

  <div class="tm-news-date uk-text-center uk-clearfix">

    

    <span></span>

  </div>

</div>

<div class="uk-width-large-5-6 uk-width-4-6">

  <p class="tm-news-title">

    Contratar el servicio

  </p>

  <p>

  Podra encontrar la solucion que mejor que adapte a su necesidad, lo guiaremos para encontrar el plan que mas se adapte a sus necesidades<br>

    Complete el formulario de alta con sus datos personales<br><ul class="uk-subnav uk-subnav-pill"><li class="uk-active"><a href="#">Entrando aqui</a></li></ul>


  </p>

  

</div>

</div>

</div></div>

<div class="uk-width-1-1 uk-width-medium-1-2"><div class="uk-panel widget_text"><div class="uk-grid">
 
<div class="uk-width-large-1-6 uk-width-2-6">
        <div class="tm-news-date uk-text-center uk-clearfix">
            
            <span></span>
        </div>
      </div>
      <div class="uk-width-large-5-6 uk-width-4-6">
        <p class="tm-news-title">
          Soporte tecnico
        </p>
        <p>
           Contamos con un equipo de profesionales para asegurar el correcto funcionamiento del servicio y resolver todas sus consultas.
		    <br>Telefono: 11-6091-3536
        </p>
        
      </div>
</div>

</div></div>
</section>
					
					
					
				</div>
				
	            	            	            
			</div>
		</div>
	</div>
	
	
	
		
	
	</div>
	<div class="tm-block tm-block-padding-top-bottom tm-block-primary uk-text-center">
		<div class=" uk-container uk-container-center uk-text-center">
		
		 <h3> Telefonos de contacto</h3><h2>02224-432514 / 02224-431054</h3><h3>Horarios de atencion:<br>De Lunes a Viernes de 09 a 17 horas</h3><h4>glewnet@gmail.com / info@glewnet.com.ar</h4></div>
	</div>
				<a class="tm-totop-scroller  tm-block-secondary" data-uk-smooth-scroll href="#"></a>
	
		<div class="tm-block-padding-top-bottom tm-block-secondary">
		<div class=" uk-container uk-container-center">
			<footer class="tm-footer uk-text-center uk-text-small">
<div class="uk-panel widget_text">
Copyright &copy; 2016 <a href="http://www.glewnet.com.ar/" target="_blank">GlewNet</a></div>
Diseñado por <a href="http://www.mi-internet.net/" target="_blank">Witel comunicaciones</a>
			</footer>
		</div>
	</div>
	
	
		<div id="offcanvas" class="uk-offcanvas">
		<div class="uk-offcanvas-bar uk-offcanvas-bar-flip">
		
<ul class="uk-nav uk-nav-offcanvas">

<li><a href="/" class="">Internet Banda Ancha&nbsp;&nbsp;&nbsp;&nbsp;| </a></li>
					<li><a href="/" class="">Inicio</a></li>
					<li><a href="contacto.php" class="">Contactanos</a></li>

</ul></div>
	</div>
	
</body>


</html>